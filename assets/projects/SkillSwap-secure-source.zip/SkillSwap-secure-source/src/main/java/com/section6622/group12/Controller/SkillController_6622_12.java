package com.section6622.group12.Controller;

import com.section6622.group.payload.SkillRequest_6622_12;
import com.section6622.group.payload.SkillResponse_6622_12;
import com.section6622.group12.Model.Skill_6622_12;
import com.section6622.group12.Model.User_6622_12;
import com.section6622.group12.Repository.SkillRepository_6622_12;
import com.section6622.group12.Repository.UserRepository_6622_12;
import com.section6622.group12.Security.JwtUtil_6622_12;
import com.section6622.group12.Service.CreditService_6622_12;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/skills")
public class SkillController_6622_12 {

    @Autowired
    private SkillRepository_6622_12 skillRepo;

    @Autowired
    private UserRepository_6622_12 userRepo;

    @Autowired
    private JwtUtil_6622_12 jwtUtil;

    @Autowired
    private CreditService_6622_12 creditService;

    @GetMapping
    public ResponseEntity<List<SkillResponse_6622_12>> getAllSkills() {
        List<Skill_6622_12> skills = skillRepo.findAllWithMentor();
        List<SkillResponse_6622_12> response = skills.stream()
            .map(skill -> new SkillResponse_6622_12(
                skill.getId(),
                skill.getTitle(),
                skill.getDescription(),
                skill.getDuration(),
                skill.getRewardPoints(),
                skill.getMentor() != null ? skill.getMentor().getUsername() : "Unknown"
            ))
            .collect(Collectors.toList());
        return ResponseEntity.ok(response);
    }

    @PostMapping
    public ResponseEntity<String> publishSkill(@RequestBody SkillRequest_6622_12 request) {
        try {
            if (request.getTitle() == null ||
                request.getDescription() == null ||
                request.getDuration() == null ||
                request.getMentorUsername() == null ||
                request.getRewardPoints() == null)
            {
                return ResponseEntity.badRequest().body("Missing one or more required fields.");
            }
            Optional<User_6622_12> mentorOpt = userRepo.findByUsername(request.getMentorUsername());
            if (mentorOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Mentor not found.");
            }
            Skill_6622_12 skill = new Skill_6622_12();
            skill.setTitle(request.getTitle());
            skill.setDescription(request.getDescription());
            skill.setDuration(request.getDuration());
            skill.setMentor(mentorOpt.get());
            skill.setRewardPoints(request.getRewardPoints());
            skillRepo.save(skill);
            return ResponseEntity.ok("Skill published successfully.");
        }
        catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("Failed to publish skill: " + e.getMessage());
        }
    }

    @PostMapping("/{skillId}/register")
    public ResponseEntity<String> registerToSkill(
            @PathVariable Long skillId,
            HttpServletRequest request
    ) {
        try {
            String authHeader = request.getHeader("Authorization");
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Missing or invalid token.");
            }
            String rawToken = authHeader.substring(7).trim();
            String username;
            if ("mock-token".equals(rawToken)) {
                username = request.getHeader("X-Username");
                if (username == null || username.isEmpty()) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("For mock-token, X-Username must be provided.");
                }
            } else {
                try {
                    username = jwtUtil.extractUsername(rawToken);
                } catch (Exception ex) {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid token: " + ex.getMessage());
                }
            }
            Optional<User_6622_12> userOpt = userRepo.findByUsername(username);
            if (userOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found.");
            }
            Optional<Skill_6622_12> skillOpt = skillRepo.findById(skillId);
            if (skillOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Skill not found.");
            }
            User_6622_12 user = userOpt.get();
            Skill_6622_12 skill = skillOpt.get();
            if (skill.getRegisteredUsers() == null) {
                skill.setRegisteredUsers(new HashSet<>());
            }
            skill.getRegisteredUsers().add(user);
            skillRepo.save(skill);
            if (user.getLearnedSkills() == null) {
                user.setLearnedSkills(new ArrayList<>());
            }
            if (!user.getLearnedSkills().contains(skill.getTitle())) {
                user.getLearnedSkills().add(skill.getTitle());
                userRepo.save(user);
            }
            return ResponseEntity.ok("User registered to skill successfully.");
        }
        catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("Error during registration: " + e.getMessage());
        }
    }

    @PutMapping("/{skillId}")
    public ResponseEntity<String> updateSkill(
            @PathVariable Long skillId,
            @RequestBody SkillRequest_6622_12 skillRequest,
            HttpServletRequest request
    ) {
        try {
            String authHeader = request.getHeader("Authorization");
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Missing or invalid token.");
            }
            String rawToken = authHeader.substring(7).trim();
            String username;
            if ("mock-token".equals(rawToken)) {
                username = skillRequest.getMentorUsername();
                if (username == null || username.isEmpty()) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("For mock-token, mentorUsername must be provided in the request body.");
                }
            } else {
                try {
                    username = jwtUtil.extractUsername(rawToken);
                } catch (Exception ex) {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid token: " + ex.getMessage());
                }
            }
            Optional<User_6622_12> userOpt = userRepo.findByUsername(username);
            if (userOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found.");
            }
            Optional<Skill_6622_12> skillOpt = skillRepo.findById(skillId);
            if (skillOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Skill not found.");
            }
            Skill_6622_12 skill = skillOpt.get();
            if (skill.getMentor() == null || !skill.getMentor().getUsername().equals(username)) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("You are not authorized to update this skill.");
            }
            if (skillRequest.getTitle() != null) {
                skill.setTitle(skillRequest.getTitle());
            }
            if (skillRequest.getDescription() != null) {
                skill.setDescription(skillRequest.getDescription());
            }
            if (skillRequest.getDuration() != null) {
                skill.setDuration(skillRequest.getDuration());
            }
            if (skillRequest.getRewardPoints() != null) {
                skill.setRewardPoints(skillRequest.getRewardPoints());
            }
            skillRepo.save(skill);
            return ResponseEntity.ok("Skill updated successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error during update: " + e.getMessage());
        }
    }

    @PutMapping("/{skillId}/complete")
    public ResponseEntity<String> completeSkill(
            @PathVariable Long skillId,
            HttpServletRequest request
    ) {
        try {
            String authHeader = request.getHeader("Authorization");
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Missing or invalid token.");
            }
            String rawToken = authHeader.substring(7).trim();
            String username;
            if ("mock-token".equals(rawToken)) {
                username = request.getHeader("X-Username");
                if (username == null || username.isEmpty()) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("For mock-token, X-Username must be provided.");
                }
            } else {
                try {
                    username = jwtUtil.extractUsername(rawToken);
                } catch (Exception ex) {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid token: " + ex.getMessage());
                }
            }
            Optional<User_6622_12> userOpt = userRepo.findByUsername(username);
            if (userOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found.");
            }
            Optional<Skill_6622_12> skillOpt = skillRepo.findById(skillId);
            if (skillOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Skill not found.");
            }
            User_6622_12 user = userOpt.get();
            Skill_6622_12 skill = skillOpt.get();
            String title = skill.getTitle();
            if (user.getLearnedSkills() == null) {
                user.setLearnedSkills(new ArrayList<>());
            }
            if (user.getKnownSkills() == null) {
                user.setKnownSkills(new ArrayList<>());
            }
            if (!user.getLearnedSkills().contains(title)) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("User has not registered to this skill.");
            }
            user.getLearnedSkills().remove(title);
            if (!user.getKnownSkills().contains(title)) {
                user.getKnownSkills().add(title);
            }
            userRepo.save(user);
            Integer points = skill.getRewardPoints() == null ? 0 : skill.getRewardPoints();
            creditService.addCredits(username, points, "Completed skill: " + title);
            return ResponseEntity.ok("Skill marked as completed. You earned " + points + " points!");
        }
        catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error during completion: " + e.getMessage());
        }
    }
}
