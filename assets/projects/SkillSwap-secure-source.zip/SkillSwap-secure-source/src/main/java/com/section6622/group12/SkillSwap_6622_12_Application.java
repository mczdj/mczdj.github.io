package com.section6622.group12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkillSwap_6622_12_Application {
    public static void main(String[] args) {
        SpringApplication.run(SkillSwap_6622_12_Application.class, args);
    }
}
