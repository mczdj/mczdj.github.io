package com.section6622.group12.Model;

import java.util.Set;

import jakarta.persistence.*;

@Entity
@Table(name = "skills")
public class Skill_6622_12 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String description;
    private Integer duration;

    @Column(nullable = false)
    private Integer rewardPoints;

    @ManyToOne
    @JoinColumn(name = "mentor_id", nullable = false)
    private User_6622_12 mentor;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "skill_registrations",
        joinColumns = @JoinColumn(name = "skill_id"),
        inverseJoinColumns = @JoinColumn(name = "user_id")
    )
    private Set<User_6622_12> registeredUsers;

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer integer) {
        this.duration = integer;
    }

    public Integer getRewardPoints() {
        return rewardPoints;
    }

    public void setRewardPoints(Integer rewardPoints) {
        this.rewardPoints = rewardPoints;
    }

    public User_6622_12 getMentor() {
        return mentor;
    }

    public void setMentor(User_6622_12 mentor) {
        this.mentor = mentor;
    }

    public Set<User_6622_12> getRegisteredUsers() {
        return registeredUsers;
    }

    public void setRegisteredUsers(Set<User_6622_12> registeredUsers) {
        this.registeredUsers = registeredUsers;
    }
}
