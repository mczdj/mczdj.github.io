package com.section6622.group12.Service;

import com.section6622.group12.Model.User_6622_12;
import java.util.Optional;

public interface UserService_6622_12 {
    void registerUser(User_6622_12 user);
    Optional<User_6622_12> login(String username, String password);
}