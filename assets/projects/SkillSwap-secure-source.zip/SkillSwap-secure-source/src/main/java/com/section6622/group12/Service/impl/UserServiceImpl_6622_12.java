package com.section6622.group12.Service.impl;

import com.section6622.group12.Model.User_6622_12;
import com.section6622.group12.Repository.UserRepository_6622_12;
import com.section6622.group12.Service.UserService_6622_12;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl_6622_12 implements UserService_6622_12 {

    @Autowired
    private UserRepository_6622_12 userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void registerUser(User_6622_12 user) {
        if (userRepository.findByUsername(user.getUsername()).isPresent()) {
            throw new IllegalArgumentException("Username already taken.");
        }

        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);
        userRepository.save(user);
    }

    @Override
    public Optional<User_6622_12> login(String username, String rawPassword) {
        Optional<User_6622_12> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            User_6622_12 user = userOpt.get();
            if (passwordEncoder.matches(rawPassword, user.getPassword())) {
                return Optional.of(user);
            }
        }
        return Optional.empty();
    }
} 
