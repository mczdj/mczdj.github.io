package com.section6622.group.payload;

public class SkillResponse_6622_12 {
    private Long id;
    private String title;
    private String description;
    private Integer duration;
    private Integer rewardPoints;
    private String mentorUsername;

    public SkillResponse_6622_12(Long id, String title, String description, Integer duration, Integer rewardPoints, String mentorUsername) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.duration = duration;
        this.rewardPoints = rewardPoints;
        this.mentorUsername = mentorUsername;
    }

    public SkillResponse_6622_12(Long id2, String title2, String description2, Integer duration2, Object object) {
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public Integer getDuration() {
        return duration;
    }

    public Integer getRewardPoints() {
        return rewardPoints;
    }

    public String getMentorUsername() {
        return mentorUsername;
    }
}
