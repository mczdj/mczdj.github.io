package com.section6622.group12.Service;

import com.section6622.group12.Model.CreditTransaction_6622_12;
import com.section6622.group12.Model.User_6622_12;
import com.section6622.group12.Repository.CreditTransactionRepository_6622_12;
import com.section6622.group12.Repository.UserRepository_6622_12;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class CreditService_6622_12 {

    @Autowired
    private UserRepository_6622_12 userRepo;

    @Autowired
    private CreditTransactionRepository_6622_12 txRepo;

    @Transactional
    public void addCredits(String username, Integer amount, String description) {
        Optional<User_6622_12> userOpt = userRepo.findByUsername(username);
        if (userOpt.isEmpty()) {
            throw new IllegalArgumentException("User not found");
        }
        User_6622_12 user = userOpt.get();
        int newBalance = user.getCreditBalance() + amount;
        user.setCreditBalance(newBalance);
        userRepo.save(user);

        CreditTransaction_6622_12 tx = new CreditTransaction_6622_12();
        tx.setUser(user);
        tx.setAmount(amount);
        tx.setDescription(description);
        tx.setTimestamp(LocalDateTime.now());
        txRepo.save(tx);
    }

    public Integer getBalance(String username) {
        return userRepo.findByUsername(username)
                       .map(User_6622_12::getCreditBalance)
                       .orElseThrow(() -> new IllegalArgumentException("User not found"));
    }

    public List<CreditTransaction_6622_12> getHistory(String username) {
        User_6622_12 user = userRepo.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        return txRepo.findByUserOrderByTimestampDesc(user);
    }
}
