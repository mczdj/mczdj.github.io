package com.section6622.group12.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.section6622.group12.Model.User_6622_12;
import com.section6622.group12.Service.UserService_6622_12;

import java.util.Optional;

@RestController
public class AuthController_6622_12 {

    @Autowired
    private UserService_6622_12 userService;

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody User_6622_12 user) {
        try {
            userService.registerUser(user);
            return ResponseEntity.ok("User registered successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                 .body("Registration failed: " + e.getMessage());
        }
    }



    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody User_6622_12 loginRequest) {
        try {
            Optional<User_6622_12> userOpt = userService.login(
                loginRequest.getUsername(), loginRequest.getPassword());

            if (userOpt.isPresent()) {
                return ResponseEntity.ok("Login successful");
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
            }
        } catch (Exception e) {
            e.printStackTrace(); // Log the exception in your console
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("Login failed: " + e.getMessage());
        }
    }
}
