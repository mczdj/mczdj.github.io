package com.section6622.group12.Model;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class User_6622_12 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    private String password;
    private String role;
    @Column(nullable = false)
    private Integer creditBalance = 0;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<CreditTransaction_6622_12> creditTransactions;
    @ElementCollection
    private List<String> knownSkills;

    @ElementCollection
    private List<String> learnedSkills;

    @OneToMany(mappedBy = "mentor", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Skill_6622_12> teachingSkills;

    // Constructors
    public User_6622_12() {
    }

    public User_6622_12(String username, String password, String role) {
        this.username = username;
        this.password = password;
        this.role = role;
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public List<String> getKnownSkills() {
        return knownSkills;
    }

    public void setKnownSkills(List<String> knownSkills) {
        this.knownSkills = knownSkills;
    }

    public List<String> getLearnedSkills() {
        return learnedSkills;
    }

    public void setLearnedSkills(List<String> learnedSkills) {
        this.learnedSkills = learnedSkills;
    }

    public List<Skill_6622_12> getTeachingSkills() {
        return teachingSkills;
    }

    public void setTeachingSkills(List<Skill_6622_12> teachingSkills) {
        this.teachingSkills = teachingSkills;
    }
    public Integer getCreditBalance() {
        return creditBalance;
    }

    public void setCreditBalance(Integer creditBalance) {
        this.creditBalance = creditBalance;
    }

    public List<CreditTransaction_6622_12> getCreditTransactions() {
        return creditTransactions;
    }

    public void setCreditTransactions(List<CreditTransaction_6622_12> creditTransactions) {
        this.creditTransactions = creditTransactions;
    }
}
