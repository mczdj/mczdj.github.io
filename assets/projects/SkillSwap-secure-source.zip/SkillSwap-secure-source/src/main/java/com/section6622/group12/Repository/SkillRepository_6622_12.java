package com.section6622.group12.Repository;

import com.section6622.group12.Model.Skill_6622_12;
import com.section6622.group12.Model.User_6622_12;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface SkillRepository_6622_12 extends JpaRepository<Skill_6622_12, Long> {

    @Query("SELECT s FROM Skill_6622_12 s JOIN FETCH s.mentor")
    List<Skill_6622_12> findAllWithMentor();

    List<Skill_6622_12> findByRegisteredUsersContains(User_6622_12 user);

	List<Skill_6622_12> findByMentorUsername(String username);
}
