package com.section6622.group12.Controller;

import com.section6622.group12.Model.CreditTransaction_6622_12;
import com.section6622.group12.Service.CreditService_6622_12;

import jakarta.servlet.http.HttpServletRequest;

import com.section6622.group12.Security.JwtUtil_6622_12;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/credits")
public class CreditController_6622_12 {

    @Autowired
    private CreditService_6622_12 creditService;

    @Autowired
    private JwtUtil_6622_12 jwtUtil;

    private String extractUsername(HttpServletRequest request) {
        String auth = request.getHeader("Authorization");
        if (auth == null || !auth.startsWith("Bearer ")) {
            throw new IllegalArgumentException("Missing or invalid token");
        }
        String raw = auth.substring(7).trim();
        if ("mock-token".equals(raw)) {
            String user = request.getHeader("X-Username");
            if (user == null) {
                throw new IllegalArgumentException("For mock-token, X-Username header required");
            }
            return user;
        }
        return jwtUtil.extractUsername(raw);
    }

    @GetMapping
    public ResponseEntity<Map<String, Object>> getCredits(HttpServletRequest request) {
        String username = extractUsername(request);
        Integer balance = creditService.getBalance(username);
        List<CreditTransaction_6622_12> history = creditService.getHistory(username);
        Map<String, Object> resp = new HashMap<>();
        resp.put("balance", balance);
        resp.put("history", history);
        return ResponseEntity.ok(resp);
    }

    @PostMapping("/add")
    public ResponseEntity<String> addCredits(
            HttpServletRequest request,
            @RequestBody Map<String, Object> payload
    ) {
        String username = extractUsername(request);
        Integer amount = (Integer) payload.get("amount");
        String description = (String) payload.get("description");
        creditService.addCredits(username, amount, description);
        return ResponseEntity.ok("Credits updated");
    }
}
