package com.section6622.group12.Controller;

import com.section6622.group12.Model.User_6622_12;
import com.section6622.group12.Model.Skill_6622_12;
import com.section6622.group12.Repository.UserRepository_6622_12;
import com.section6622.group12.Repository.SkillRepository_6622_12;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/user")
public class UserProfileController_6622_12 {

    @Autowired
    private UserRepository_6622_12 userRepository;

    @Autowired
    private SkillRepository_6622_12 skillRepository;

    @GetMapping("/profile/{username}")
    public ResponseEntity<Map<String, Object>> getUserProfile(@PathVariable String username) {
        Optional<User_6622_12> userOpt = userRepository.findByUsername(username);

        if (userOpt.isEmpty()) {
            return ResponseEntity.status(404).body(Map.of("error", "User not found"));
        }

        User_6622_12 user = userOpt.get();

        Map<String, Object> response = new HashMap<>();
        response.put("username", user.getUsername());
        response.put("role", user.getRole());

        // Known & learned skills
        response.put("knownSkills", Optional.ofNullable(user.getKnownSkills()).orElse(List.of()));
        response.put("learnedSkills", Optional.ofNullable(user.getLearnedSkills()).orElse(List.of()));

        // Teaching skills
        List<Skill_6622_12> teachingSkills = skillRepository.findByMentorUsername(user.getUsername());
        List<Map<String, Object>> skillData = new ArrayList<>();

        for (Skill_6622_12 skill : teachingSkills) {
            Map<String, Object> s = new HashMap<>();
            s.put("id", skill.getId());
            s.put("title", skill.getTitle());
            s.put("description", skill.getDescription());
            s.put("duration", skill.getDuration());
            skillData.add(s);
        }

        response.put("teachingSkills", skillData);

        return ResponseEntity.ok(response);
    }
}
