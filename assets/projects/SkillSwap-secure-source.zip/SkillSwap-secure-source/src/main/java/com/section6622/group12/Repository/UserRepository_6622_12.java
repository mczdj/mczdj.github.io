package com.section6622.group12.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.section6622.group12.Model.User_6622_12;

@Repository
public interface UserRepository_6622_12 extends JpaRepository<User_6622_12, Long> {
    Optional<User_6622_12> findByUsername(String username);
}
