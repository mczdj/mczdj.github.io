package com.section6622.group12.Repository;

import com.section6622.group12.Model.CreditTransaction_6622_12;
import com.section6622.group12.Model.User_6622_12;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CreditTransactionRepository_6622_12 extends JpaRepository<CreditTransaction_6622_12, Long> {
    List<CreditTransaction_6622_12> findByUserOrderByTimestampDesc(User_6622_12 user);
}
