# Secure local database setup

The original database password has been removed from the source code. The application now reads database and JWT credentials from environment variables.

## 1. Change the MySQL password locally

Open MySQL:

```bash
mysql -u root -p
```

Then run the following command after replacing the placeholder with a strong password:

```sql
ALTER USER 'root'@'localhost' IDENTIFIED BY 'YOUR_NEW_STRONG_PASSWORD';
FLUSH PRIVILEGES;
```

This command must be executed on the computer where MySQL is installed. Changing `application.properties` alone does not change the MySQL account password.

## 2. Set the environment variables

### Windows PowerShell - current terminal

```powershell
$env:DB_USERNAME = "root"
$env:DB_PASSWORD = "YOUR_NEW_STRONG_PASSWORD"
$env:JWT_SECRET = "A_RANDOM_SECRET_WITH_AT_LEAST_32_CHARACTERS"
.\mvnw.cmd spring-boot:run
```

### macOS or Linux - current terminal

```bash
export DB_USERNAME="root"
export DB_PASSWORD="YOUR_NEW_STRONG_PASSWORD"
export JWT_SECRET="A_RANDOM_SECRET_WITH_AT_LEAST_32_CHARACTERS"
./mvnw spring-boot:run
```

## 3. GitHub safety

- Never commit a real `.env` file.
- Never hardcode database passwords or JWT secrets.
- Private key files such as `.p12`, `.jks`, and `.keystore` are ignored.
- The compiled `target` directory is not included because it previously contained a copied configuration file.
